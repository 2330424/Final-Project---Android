package com.example.finalproject;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CartActivity extends AppCompatActivity {

    private TextView itemBrandTextView, itemPriceTextView, quantityTextView, sizeTextView, totalPriceTextView;
    private Button paymentButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        // Initialize TextViews
        itemBrandTextView = findViewById(R.id.item_brand_cart);
        itemPriceTextView = findViewById(R.id.item_price_cart);
        quantityTextView = findViewById(R.id.quantity_cart);
        sizeTextView = findViewById(R.id.size_cart);
        totalPriceTextView = findViewById(R.id.total_price_cart);

        // Initialize Button
        paymentButton = findViewById(R.id.payment_button);

        // Retrieve data from Intent
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String itemBrand = extras.getString("ITEM_BRAND");
            String itemPrice = extras.getString("ITEM_PRICE");
            int quantity = extras.getInt("QUANTITY");
            String size = extras.getString("SIZE");
            double totalPrice = extras.getDouble("TOTAL_PRICE");

            // Set formatted data to TextViews
            itemBrandTextView.setText("Brand: " + itemBrand);
            itemPriceTextView.setText("Price:" + itemPrice);
            quantityTextView.setText("Quantity: " + quantity);
            sizeTextView.setText("Size: " + size);
            totalPriceTextView.setText("Total Price: -$" + totalPrice);
        }

        // Set onClickListener for the payment button
        paymentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Display a toast message when the button is clicked
                Toast.makeText(CartActivity.this, "Order placed successfully!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

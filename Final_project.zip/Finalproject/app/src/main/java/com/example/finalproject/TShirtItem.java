package com.example.finalproject;

public class TShirtItem {
    private int imageResource;
    private String brand;
    private String price;

    public TShirtItem(int imageResource, String brand, String price) {
        this.imageResource = imageResource;
        this.brand = brand;
        this.price = price;
    }

    public int getImageResource() {
        return imageResource;
    }

    public String getBrand() {
        return brand;
    }

    public String getPrice() {
        return price;
    }
}


package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth auth;
    private Button button;

    private FirebaseUser user;

    private RecyclerView recyclerView;
    private TShirtAdapter adapter;
    private List<TShirtItem> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Firebase authentication
        auth = FirebaseAuth.getInstance();

        // Initialize views
        button = findViewById(R.id.logout);
        recyclerView = findViewById(R.id.recyclerView);

        // Check if user is authenticated
        user = auth.getCurrentUser();
        if (user == null) {
            // Redirect to login activity if user is not logged in
            Intent intent = new Intent(getApplicationContext(), Login.class);
            startActivity(intent);
            finish();
        }

        // Set up RecyclerView
        itemList = new ArrayList<>();
        itemList.add(new TShirtItem(R.drawable.tshirt1, "Nike", "$19.99"));
        itemList.add(new TShirtItem(R.drawable.tshirt2, "Adidas", "$29.99"));
        itemList.add(new TShirtItem(R.drawable.tshirt3, "H&M", "$24.99"));
        itemList.add(new TShirtItem(R.drawable.tshirt4, "Zara", "$39.99"));
        itemList.add(new TShirtItem(R.drawable.tshirt5, "Gap", "$29.99"));
        itemList.add(new TShirtItem(R.drawable.tshirt6, "Tommy Hilfiger", "$34.99"));
        // Add more items as needed

        adapter = new TShirtAdapter(itemList, new TShirtAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                // Handle item click (e.g., open details activity)
                TShirtItem selectedItem = itemList.get(position);
                Intent intent = new Intent(MainActivity.this, ItemDetailsActivity.class);
                intent.putExtra("ITEM_IMAGE", selectedItem.getImageResource());
                intent.putExtra("ITEM_BRAND", selectedItem.getBrand());
                intent.putExtra("ITEM_PRICE", selectedItem.getPrice());
                startActivity(intent);
            }
        });
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Set onClickListener for logout button
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Sign out user
                FirebaseAuth.getInstance().signOut();
                // Redirect to login activity
                Intent intent = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);
                finish();
            }
        });
    }
}

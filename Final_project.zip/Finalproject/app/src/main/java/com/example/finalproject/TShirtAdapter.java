package com.example.finalproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TShirtAdapter extends RecyclerView.Adapter<TShirtAdapter.ViewHolder> {

    private List<TShirtItem> itemList;
    private OnItemClickListener mListener;

    // Interface for handling item clicks
    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public TShirtAdapter(List<TShirtItem> itemList, OnItemClickListener listener) {
        this.itemList = itemList;
        this.mListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tshirt, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TShirtItem item = itemList.get(position);
        holder.itemImage.setImageResource(item.getImageResource());
        holder.itemBrand.setText(item.getBrand());
        holder.itemPrice.setText(item.getPrice());

        // Set click listener for the "View Details" button
        holder.viewDetailsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.onItemClick(position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView itemImage;
        TextView itemBrand;
        TextView itemPrice;
        Button viewDetailsButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemImage = itemView.findViewById(R.id.item_image);
            itemBrand = itemView.findViewById(R.id.item_brand);
            itemPrice = itemView.findViewById(R.id.item_price);
            viewDetailsButton = itemView.findViewById(R.id.view_details_button);
        }
    }
}

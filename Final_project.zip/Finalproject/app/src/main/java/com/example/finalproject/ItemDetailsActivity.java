package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.NumberPicker;
import android.widget.Spinner;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;

public class ItemDetailsActivity extends AppCompatActivity {

    private ImageView imageView;
    private TextView brandTextView, priceTextView, additionalInfoTextView;
    private NumberPicker quantityPicker;
    private Spinner sizeSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_details);

        // Initialize views
        // Initialize views
        imageView = findViewById(R.id.item_image_details);
        brandTextView = findViewById(R.id.item_brand_details);
        priceTextView = findViewById(R.id.item_price_details);
        additionalInfoTextView = findViewById(R.id.item_additional_info);
        quantityPicker = findViewById(R.id.quantity_picker);
        sizeSpinner = findViewById(R.id.size_spinner);
        Button addToCartButton = findViewById(R.id.add_to_cart_button); // Added line

// Retrieve the extras from the Intent
        Intent intent = getIntent();
        int itemImageResource = intent.getIntExtra("ITEM_IMAGE", 0); // Default value if not found
        String itemBrand = intent.getStringExtra("ITEM_BRAND");
        String itemPrice = intent.getStringExtra("ITEM_PRICE");
        String itemSize = intent.getStringExtra("ITEM_SIZE");

// Set values to views
        imageView.setImageResource(itemImageResource);
        brandTextView.setText(itemBrand);
        priceTextView.setText(itemPrice);

// Set additional information about the product
        String additionalInfo = "Made from breathable cotton fabric, perfect for workouts or casual wear. Ideal for staying comfortable during exercise or for everyday use.";
        additionalInfoTextView.setText(additionalInfo);

// Configure the quantity picker
        quantityPicker.setMinValue(1);
        quantityPicker.setMaxValue(5);
        quantityPicker.setWrapSelectorWheel(true); // Optional setting

// Configure the size spinner
        ArrayAdapter<CharSequence> sizeAdapter = ArrayAdapter.createFromResource(this,
                R.array.size_options, android.R.layout.simple_spinner_item);
        sizeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sizeSpinner.setAdapter(sizeAdapter);

// Set the selected size in the spinner
        if (itemSize != null) {
            int spinnerPosition = sizeAdapter.getPosition(itemSize);
            sizeSpinner.setSelection(spinnerPosition);
        }

// Set onClickListener for add to cart button
        addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int quantity = quantityPicker.getValue();
                String selectedSize = sizeSpinner.getSelectedItem().toString();

                // Extract the numeric part of the price string (remove currency symbol and any non-numeric characters)
                String numericPrice = itemPrice.replaceAll("[^\\d.]", ""); // Remove non-numeric characters except decimal point
                double price = Double.parseDouble(numericPrice); // Parse the numeric part as a double

                // Calculate total price
                double totalPrice = quantity * price;

                // Start CartActivity and pass data
                Intent cartIntent = new Intent(ItemDetailsActivity.this, CartActivity.class);
                cartIntent.putExtra("ITEM_IMAGE", itemImageResource);
                cartIntent.putExtra("ITEM_BRAND", itemBrand);
                cartIntent.putExtra("ITEM_PRICE", itemPrice);
                cartIntent.putExtra("QUANTITY", quantity);
                cartIntent.putExtra("SIZE", selectedSize);
                cartIntent.putExtra("TOTAL_PRICE", totalPrice);
                startActivity(cartIntent);
            }
        });

    }
}
